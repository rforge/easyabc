### R code from vignette source 'EasyABC.Rnw'

